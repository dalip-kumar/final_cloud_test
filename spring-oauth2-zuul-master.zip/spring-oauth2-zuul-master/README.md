# spring-oauth2-zuul
Spring-Boot projects using: Zuul, Cloud OAuth2 OAuth2Sso and Spring Security

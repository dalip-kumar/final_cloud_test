package com.metallica.referencedata.service;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.metallica.common.dto.CounterParty;

public interface CounterPartyRepo extends MongoRepository<CounterParty, String>{

	public List<CounterParty> findBySym(String sym);
}

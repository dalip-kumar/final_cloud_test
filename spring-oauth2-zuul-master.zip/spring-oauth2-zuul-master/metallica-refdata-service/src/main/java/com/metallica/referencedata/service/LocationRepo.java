/**
 * 
 */
package com.metallica.referencedata.service;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.metallica.common.dto.Location;

/**
 * @author dkum74
 *
 */
public interface LocationRepo extends MongoRepository<Location, String> {

	public List<Location> findByCode(String code);
}

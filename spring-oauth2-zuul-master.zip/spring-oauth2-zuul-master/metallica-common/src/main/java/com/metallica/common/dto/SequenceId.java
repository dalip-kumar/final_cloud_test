package com.metallica.common.dto;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Document(collection = "sequence")
@AllArgsConstructor @NoArgsConstructor @Getter @Setter @ToString
public class SequenceId {

	@Id
	private String id;

	private long seq;

}
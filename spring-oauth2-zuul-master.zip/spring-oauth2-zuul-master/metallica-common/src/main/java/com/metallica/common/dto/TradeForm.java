/**
 * 
 */
package com.metallica.common.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @author dkum74
 *
 */
@AllArgsConstructor @NoArgsConstructor @Getter @Setter @ToString
public class TradeForm {

	/**
	 * 
	 */

	private String tradeId;
	
	private String side;
	
	private String quantity;
	
	private String price;
	
	private String tradeDate;
	
	private String status;

	private String commodity;
	
	private String counterParty;
	
	private String location;

}	
	
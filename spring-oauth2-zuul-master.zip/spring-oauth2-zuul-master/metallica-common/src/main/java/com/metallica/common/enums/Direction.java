package com.metallica.common.enums;

public enum Direction {
	UP,
	DOWN;
}
